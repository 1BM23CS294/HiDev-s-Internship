import { GoogleGenAI, Type } from "@google/genai";
import { LogEntry, AnalysisResult } from "../types";

// Initialize Gemini Client
// NOTE: In a real production app, this would be a backend call to protect the key.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeLogsWithGemini = async (logs: LogEntry[]): Promise<AnalysisResult> => {
  const logData = logs.map(l => `[${l.timestamp}] [${l.level}] [${l.service}]: ${l.message} ${JSON.stringify(l.metadata || {})}`).join('\n');

  const prompt = `
    You are an expert DevOps and Security Engineer. Analyze the following server logs.
    Look for:
    1. Pattern of errors or failures.
    2. Security threats (like brute force, SQL injection).
    3. Performance bottlenecks.
    
    Logs:
    ${logData}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            riskLevel: { type: Type.STRING, enum: ["LOW", "MEDIUM", "HIGH", "CRITICAL"] },
            anomalies: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  description: { type: Type.STRING },
                  severity: { type: Type.STRING }
                }
              }
            },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};