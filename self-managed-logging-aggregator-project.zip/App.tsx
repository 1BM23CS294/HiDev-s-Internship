import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import LogViewer from './components/LogViewer';
import AIAnalyzer from './components/AIAnalyzer';
import Documentation from './components/Documentation';
import { MOCK_LOGS } from './constants';
import { LogEntry, LogLevel } from './types';

const App: React.FC = () => {
  // In a real app, logs would be fetched from an API/Socket
  const [logs, setLogs] = useState<LogEntry[]>([]);

  useEffect(() => {
    // Simulate fetching logs
    setLogs(MOCK_LOGS);
    
    // Simulate live incoming logs
    const interval = setInterval(() => {
      const newLog: LogEntry = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        level: Math.random() > 0.9 ? LogLevel.ERROR : LogLevel.INFO,
        service: Math.random() > 0.5 ? 'payment-gateway' : 'auth-service',
        message: Math.random() > 0.9 ? 'Transaction timeout' : 'Heartbeat received',
      };
      // Keep the log list from growing infinitely for this demo
      setLogs(prev => [newLog, ...prev].slice(0, 100));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard logs={logs} />} />
          <Route path="/logs" element={<LogViewer logs={logs} />} />
          <Route path="/analysis" element={<AIAnalyzer logs={logs} />} />
          <Route path="/docs" element={<Documentation />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;