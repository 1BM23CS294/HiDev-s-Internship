import React, { useState } from 'react';
import { LogEntry, LogLevel } from '../types';

interface LogViewerProps {
  logs: LogEntry[];
}

const LogViewer: React.FC<LogViewerProps> = ({ logs }) => {
  const [filter, setFilter] = useState('');
  const [levelFilter, setLevelFilter] = useState<string>('ALL');

  const filteredLogs = logs.filter(log => {
    const matchesText = log.message.toLowerCase().includes(filter.toLowerCase()) || 
                        log.service.toLowerCase().includes(filter.toLowerCase());
    const matchesLevel = levelFilter === 'ALL' || log.level === levelFilter;
    return matchesText && matchesLevel;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b-2 border-green-900 pb-4">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase">Log_Explorer</h2>
          <p className="text-green-700 text-sm">Viewing raw data from /var/log/syslog</p>
        </div>
        <button className="px-4 py-1 bg-green-900 text-green-300 text-sm hover:bg-green-800 uppercase">
          [ Download_CSV ]
        </button>
      </div>

      {/* Inputs */}
      <div className="flex flex-col md:flex-row gap-4 p-4 border-2 border-green-900 bg-black">
        <div className="flex-1">
          <label className="block text-xs text-green-700 mb-1">SEARCH_QUERY:</label>
          <input 
            type="text" 
            placeholder="grep 'message'..." 
            className="w-full bg-black border-b border-green-500 text-green-400 focus:outline-none focus:border-white p-1 font-mono"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        </div>
        <div>
            <label className="block text-xs text-green-700 mb-1">FILTER_LEVEL:</label>
            <select 
                className="bg-black border border-green-500 text-green-400 p-1 font-mono focus:outline-none"
                value={levelFilter}
                onChange={(e) => setLevelFilter(e.target.value)}
            >
                <option value="ALL">*</option>
                <option value={LogLevel.INFO}>INFO</option>
                <option value={LogLevel.WARN}>WARN</option>
                <option value={LogLevel.ERROR}>ERROR</option>
                <option value={LogLevel.FATAL}>FATAL</option>
            </select>
        </div>
      </div>

      {/* Terminal Window */}
      <div className="border-2 border-green-800 bg-black min-h-[400px] font-mono text-xs md:text-sm">
        <div className="bg-green-900/20 p-2 border-b border-green-800 flex gap-4 text-green-300 font-bold uppercase">
          <div className="w-24">Time</div>
          <div className="w-16">Lvl</div>
          <div className="w-32">Service</div>
          <div className="flex-1">Message</div>
        </div>
        <div className="p-2 space-y-1">
          {filteredLogs.length > 0 ? (
            filteredLogs.map((log) => (
              <div key={log.id} className="flex gap-4 hover:bg-green-900/10 cursor-default">
                <div className="w-24 text-green-600 shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</div>
                <div className={`w-16 shrink-0 font-bold ${
                  log.level === 'ERROR' || log.level === 'FATAL' ? 'text-red-500' : 
                  log.level === 'WARN' ? 'text-yellow-500' : 'text-green-400'
                }`}>
                  {log.level}
                </div>
                <div className="w-32 text-green-300 shrink-0 truncate">{log.service}</div>
                <div className="flex-1 text-gray-300 break-all">
                  {log.message} 
                  {log.metadata && <span className="text-gray-600 ml-2">{JSON.stringify(log.metadata)}</span>}
                </div>
              </div>
            ))
          ) : (
            <div className="text-green-800 p-4 italic">No entries found in buffer...</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LogViewer;