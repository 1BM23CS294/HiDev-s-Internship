import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { LogEntry, LogLevel } from '../types';

interface DashboardProps {
  logs: LogEntry[];
}

const Dashboard: React.FC<DashboardProps> = ({ logs }) => {
  const totalLogs = logs.length;
  const errorCount = logs.filter(l => l.level === LogLevel.ERROR || l.level === LogLevel.FATAL).length;
  const warningCount = logs.filter(l => l.level === LogLevel.WARN).length;

  const chartData = [
    { name: '00:00', logs: 120 },
    { name: '04:00', logs: 132 },
    { name: '08:00', logs: 450 },
    { name: '12:00', logs: 890 },
    { name: '16:00', logs: 670 },
    { name: '20:00', logs: 210 },
    { name: '23:59', logs: 150 },
  ];

  const serviceHealthData = [
      { name: 'Auth', score: 92 },
      { name: 'Pay', score: 88 },
      { name: 'DB', score: 65 },
      { name: 'Web', score: 99 },
  ];

  // Custom simple tooltip for retro feel
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-black border border-green-500 p-2 text-xs font-mono">
          <p className="text-white">{`${label} : ${payload[0].value}`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8">
      <div className="border-b-2 border-green-900 pb-4">
        <h2 className="text-2xl font-bold text-white uppercase">System_Monitor</h2>
        <p className="text-green-700 text-sm">Real-time data stream from local collectors</p>
      </div>

      {/* Stat Blocks - Raw boxes */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-black p-4 border-2 border-green-800 hover:border-green-500 transition-colors">
          <p className="text-green-700 text-xs uppercase mb-2">Total_Logs</p>
          <h3 className="text-4xl font-bold text-white">{totalLogs * 145}</h3>
        </div>

        <div className="bg-black p-4 border-2 border-green-800 hover:border-red-500 transition-colors">
          <p className="text-red-500 text-xs uppercase mb-2">Errors</p>
          <h3 className="text-4xl font-bold text-red-500">{errorCount}</h3>
        </div>

        <div className="bg-black p-4 border-2 border-green-800 hover:border-yellow-500 transition-colors">
          <p className="text-yellow-500 text-xs uppercase mb-2">Warnings</p>
          <h3 className="text-4xl font-bold text-yellow-500">{warningCount}</h3>
        </div>

        <div className="bg-black p-4 border-2 border-green-800 hover:border-green-500 transition-colors">
          <p className="text-green-700 text-xs uppercase mb-2">Uptime</p>
          <h3 className="text-4xl font-bold text-green-500">99.9%</h3>
        </div>
      </div>

      {/* Charts Area */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="border-2 border-green-900 p-4 bg-black">
          <h3 className="text-sm text-green-500 mb-4 uppercase">[ Log_Volume_Graph ]</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#14532d" />
                <XAxis dataKey="name" stroke="#22c55e" tick={{fontSize: 10}} />
                <YAxis stroke="#22c55e" tick={{fontSize: 10}} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="step" dataKey="logs" stroke="#22c55e" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="border-2 border-green-900 p-4 bg-black">
          <h3 className="text-sm text-green-500 mb-4 uppercase">[ Service_Health ]</h3>
           <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={serviceHealthData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#14532d" vertical={false} />
                <XAxis dataKey="name" stroke="#22c55e" tick={{fontSize: 10}} />
                <YAxis stroke="#22c55e" tick={{fontSize: 10}} domain={[0, 100]} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="score" fill="#22c55e" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;