
import React from 'react';

const Documentation: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-12 pb-20">
      
      {/* Header */}
      <div className="space-y-4 border-b-2 border-green-900 pb-6">
        <h1 className="text-3xl md:text-4xl font-bold text-white uppercase tracking-widest">
          READ_ME.txt
        </h1>
        <h2 className="text-xl text-green-500">
            Project: Self-Managed Logging Aggregator
        </h2>
        <p className="text-green-600 text-lg">
          Hi, welcome to my logging project!
        </p>
      </div>

      {/* Intro Section */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-white uppercase bg-green-900/30 p-2 inline-block">
          1. What is this?
        </h2>
        <p className="leading-relaxed text-green-400">
          I built this website, the <span className="text-white font-bold">Self-Managed Logging Aggregator</span>, because I wanted a free way to check my server logs. 
          Usually, companies charge a lot of money for tools like Splunk or Datadog, 
          but as a beginner developer, I don't have that kind of budget!
        </p>
        <p className="leading-relaxed text-green-400">
          This is a self-managed dashboard. It takes logs from my backend (Node.js & Python scripts), 
          stores them in a database (MongoDB/SQL), and shows them here. 
          I also added some AI magic using Google's Gemini API to tell me if someone is trying to hack me.
        </p>
      </section>

      {/* Stack Section */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-white uppercase bg-green-900/30 p-2 inline-block">
          2. Tech Stack Used
        </h2>
        <p className="text-green-400">I used a bunch of different technologies to learn how they work together:</p>
        <ul className="list-none space-y-2 pl-4 border-l-2 border-green-800">
          <li><span className="text-white font-bold">HTML & CSS:</span> The skeleton and styling of this site.</li>
          <li><span className="text-white font-bold">JavaScript (React):</span> To make the buttons work and fetch data.</li>
          <li><span className="text-white font-bold">Node.js:</span> Runs the server that collects the logs.</li>
          <li><span className="text-white font-bold">Python:</span> I use Python scripts to parse heavy text files.</li>
          <li><span className="text-white font-bold">MongoDB:</span> Stores the messy JSON logs.</li>
          <li><span className="text-white font-bold">Gemini API:</span> The brain that reads logs for me.</li>
        </ul>
      </section>

      {/* How to Run Section */}
      <section className="space-y-6">
        <h2 className="text-xl font-bold text-white uppercase bg-green-900/30 p-2 inline-block">
          3. How to run this code
        </h2>
        <p className="text-green-400">
          If you want to run this on your computer, grab the code from GitHub and follow these steps.
        </p>

        <div className="bg-yellow-900/20 border-l-4 border-yellow-500 p-4 mb-4">
            <p className="text-yellow-500 font-bold text-sm">⚠️ IMPORTANT NOTE</p>
            <p className="text-yellow-200 text-sm mt-1">
                Please use <span className="font-bold text-white">Command Prompt (cmd)</span> to run these commands. 
                Do NOT use PowerShell, as the instructions may not work correctly there.
            </p>
        </div>

        <div className="bg-gray-900 p-6 border-2 border-green-700 shadow-[4px_4px_0px_0px_rgba(34,197,94,0.3)]">
          <p className="text-gray-500 mb-2">// Step 1: Download</p>
          <p className="text-white mb-4">Download the file from GitHub in <strong>ZIP file mode</strong>.</p>
          
          <p className="text-gray-500 mb-2">// Step 2: Extract</p>
          <p className="text-white mb-4">Extract the ZIP file you just downloaded.</p>

          <p className="text-gray-500 mb-2">// Step 3: Open VS Code</p>
          <p className="text-white mb-4">Open the terminal and type <span className="text-green-400">code .</span> to open all files in VS Code.</p>

          <p className="text-gray-500 mb-2">// Step 4: Select Command Prompt</p>
          <p className="text-white mb-4">Go to the VS Code terminal and select <strong>Command Prompt</strong>.</p>

          <p className="text-gray-500 mb-2">// Step 5: Install</p>
          <p className="text-white mb-4">npm i</p>

          <p className="text-gray-500 mb-2">// Step 6: Start Server</p>
          <p className="text-white mb-4">npm run dev</p>

          <p className="text-gray-500 mb-2">// Step 7: Run Website</p>
          <p className="text-white">Ctrl + Click (or Ctrl+Enter) the localhost link to run the website.</p>
        </div>
      </section>

      {/* API Key Section */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-white uppercase bg-green-900/30 p-2 inline-block">
          4. About the API Keys
        </h2>
        <p className="text-green-400">
          To make the AI analysis work, you need a key from Google. 
          It's basically a password that lets my code talk to their brain.
        </p>
        <div className="p-4 border border-green-800 bg-green-900/10">
          <p className="text-green-300">
            I have already created a <span className="text-white font-bold">.env</span> file for you in this project folder.
          </p>
          <code className="block mt-2 text-yellow-400">
            API_KEY=AIzaSyDF6...
          </code>
        </div>
        <p className="text-sm text-green-600">
          (I've set it up so it works right now, but remember: never upload your .env file to a public GitHub repo! It contains your secret key.)
        </p>
      </section>

      <footer className="pt-10 border-t-2 border-green-900 text-center text-green-800">
        <p>Made with 💻 and ☕ by a learning developer.</p>
      </footer>
    </div>
  );
};

export default Documentation;
