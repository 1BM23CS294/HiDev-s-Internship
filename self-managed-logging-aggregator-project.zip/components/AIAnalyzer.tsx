import React, { useState } from 'react';
import { analyzeLogsWithGemini } from '../services/gemini';
import { LogEntry, AnalysisResult } from '../types';

interface AIAnalyzerProps {
  logs: LogEntry[];
}

const AIAnalyzer: React.FC<AIAnalyzerProps> = ({ logs }) => {
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await analyzeLogsWithGemini(logs);
      setAnalysis(result);
    } catch (err) {
      setError("Error: Could not connect to Gemini API. check your .env file.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="border-b-2 border-green-900 pb-4 flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase">AI_Security_Scan</h2>
          <p className="text-green-700 text-sm">Pattern detection using Gemini 2.5 Flash</p>
        </div>
      </div>

      {/* Control Panel */}
      <div className="bg-black border-2 border-green-800 p-6 text-center">
        <p className="text-green-500 mb-4">
          Ready to scan {logs.length} log entries for anomalies?
        </p>
        <button
          onClick={handleAnalyze}
          disabled={loading}
          className={`px-8 py-3 font-bold text-lg border-2 uppercase tracking-widest transition-all ${
            loading 
              ? 'border-green-900 text-green-900 cursor-wait' 
              : 'border-green-500 text-green-500 hover:bg-green-500 hover:text-black'
          }`}
        >
          {loading ? 'SCANNING_IN_PROGRESS...' : 'INITIATE_SCAN'}
        </button>
      </div>

      {error && (
        <div className="border-l-4 border-red-500 bg-red-900/10 p-4 text-red-400 font-mono">
          {`>> SYSTEM ERROR: ${error}`}
        </div>
      )}

      {/* Results Area */}
      {analysis && !loading && (
        <div className="space-y-6 animate-pulse-slow">
          <div className="border-2 border-green-500 p-6 bg-black relative">
             <span className="absolute -top-3 left-4 bg-black px-2 text-green-500 font-bold">REPORT_OUTPUT</span>
             
             <div className="mb-6">
                <h3 className="text-white font-bold mb-2 border-b border-green-900 inline-block">SUMMARY</h3>
                <p className="text-green-300 leading-relaxed font-mono">{analysis.summary}</p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 className="text-white font-bold mb-2 border-b border-green-900 inline-block">THREATS_DETECTED</h3>
                    <ul className="space-y-2">
                        {analysis.anomalies.map((a, i) => (
                            <li key={i} className="text-sm">
                                <span className="text-red-500 font-bold">[{a.severity}]</span> <span className="text-gray-400">{a.description}</span>
                            </li>
                        ))}
                    </ul>
                </div>
                
                <div>
                    <h3 className="text-white font-bold mb-2 border-b border-green-900 inline-block">ACTION_ITEMS</h3>
                    <ul className="space-y-2">
                        {analysis.recommendations.map((r, i) => (
                            <li key={i} className="text-sm text-green-400 flex gap-2">
                                <span>{`>`}</span> {r}
                            </li>
                        ))}
                    </ul>
                </div>
             </div>

             <div className="mt-6 pt-4 border-t border-green-900 text-right">
                <span className="text-xs text-green-700">RISK_LEVEL:</span> 
                <span className={`ml-2 font-bold ${
                    analysis.riskLevel === 'CRITICAL' || analysis.riskLevel === 'HIGH' ? 'text-red-500' : 'text-green-500'
                }`}>
                    {analysis.riskLevel}
                </span>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AIAnalyzer;