import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Terminal, List, Cpu, HelpCircle } from 'lucide-react';
import { NAVIGATION_ITEMS } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();

  const getIcon = (name: string) => {
    switch (name) {
      case 'Dashboard': return <Terminal size={18} />;
      case 'Log Explorer': return <List size={18} />;
      case 'AI Analysis': return <Cpu size={18} />;
      case 'Documentation': return <HelpCircle size={18} />;
      default: return <Terminal size={18} />;
    }
  };

  return (
    <div className="min-h-screen flex bg-black text-green-500 font-mono selection:bg-green-900 selection:text-white">
      {/* Sidebar - Styled like a retro side panel */}
      <aside className="w-64 border-r-2 border-green-900 hidden md:flex flex-col fixed h-full z-10 bg-black">
        <div className="p-6 border-b-2 border-green-900">
          <h1 className="text-lg font-bold tracking-tighter text-white leading-tight">
            <span className="text-green-500">{`>`}</span> SELF_MANAGED<br/>LOGGING_AGGREGATOR
          </h1>
          <span className="text-xs text-green-800 block mt-2">version: 1.0.release</span>
        </div>
        
        <nav className="flex-1 p-4 space-y-4">
          {NAVIGATION_ITEMS.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-2 transition-all duration-0 ${
                location.pathname === item.path
                  ? 'bg-green-900/40 text-white border-l-4 border-green-500'
                  : 'text-green-700 hover:text-green-400 hover:bg-green-900/20'
              }`}
            >
              {getIcon(item.name)}
              <span className="uppercase text-sm tracking-wider">{item.name}</span>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t-2 border-green-900">
          <div className="text-xs text-green-800">
            <p>STATUS: ONLINE</p>
            <p>SERVER: 127.0.0.1</p>
            <p className="mt-2 text-[10px]">"Hello World"</p>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 w-full bg-black border-b-2 border-green-900 z-20 p-4 flex justify-between items-center">
         <div className="font-bold text-white text-sm">
            <span className="text-green-500">{`>`}</span> SM_LOG_AGGREGATOR
         </div>
         <div className="flex gap-6">
             {NAVIGATION_ITEMS.map(item => (
                 <Link key={item.path} to={item.path} className="text-green-700 hover:text-green-500">
                    {getIcon(item.name)}
                 </Link>
             ))}
         </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-10 pt-20 md:pt-10 overflow-y-auto max-w-7xl mx-auto w-full">
        <div className="border-2 border-green-900/50 p-1 min-h-full relative">
            {/* Decorative corner pieces for that 'tech' feel */}
            <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-green-500 -mt-0.5 -ml-0.5"></div>
            <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-green-500 -mt-0.5 -mr-0.5"></div>
            <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-green-500 -mb-0.5 -ml-0.5"></div>
            <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-green-500 -mb-0.5 -mr-0.5"></div>
            
            <div className="p-4 md:p-8">
                {children}
            </div>
        </div>
      </main>
    </div>
  );
};

export default Layout;