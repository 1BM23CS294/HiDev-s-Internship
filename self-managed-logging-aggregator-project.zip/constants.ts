import { LogEntry, LogLevel } from './types';

export const MOCK_LOGS: LogEntry[] = [
  {
    id: 'log-001',
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    level: LogLevel.INFO,
    service: 'auth-service',
    message: 'User login successful for user_id: 8492',
    metadata: { ip: '192.168.1.105' }
  },
  {
    id: 'log-002',
    timestamp: new Date(Date.now() - 1000 * 60 * 4).toISOString(),
    level: LogLevel.WARN,
    service: 'payment-gateway',
    message: 'High latency detected in transaction processing (450ms)',
    metadata: { transaction_id: 'tx_9938' }
  },
  {
    id: 'log-003',
    timestamp: new Date(Date.now() - 1000 * 60 * 3.5).toISOString(),
    level: LogLevel.ERROR,
    service: 'database-primary',
    message: 'Connection pool exhausted, rejecting new connections',
    metadata: { active_connections: 500, max: 500 }
  },
  {
    id: 'log-004',
    timestamp: new Date(Date.now() - 1000 * 60 * 3).toISOString(),
    level: LogLevel.ERROR,
    service: 'auth-service',
    message: 'Failed login attempt: Invalid password',
    metadata: { ip: '45.22.19.112', attempts: 3 }
  },
  {
    id: 'log-005',
    timestamp: new Date(Date.now() - 1000 * 60 * 2.8).toISOString(),
    level: LogLevel.ERROR,
    service: 'auth-service',
    message: 'Failed login attempt: Invalid password',
    metadata: { ip: '45.22.19.112', attempts: 4 }
  },
  {
    id: 'log-006',
    timestamp: new Date(Date.now() - 1000 * 60 * 2.6).toISOString(),
    level: LogLevel.ERROR,
    service: 'auth-service',
    message: 'Failed login attempt: Invalid password',
    metadata: { ip: '45.22.19.112', attempts: 5 }
  },
  {
    id: 'log-007',
    timestamp: new Date(Date.now() - 1000 * 60 * 2.5).toISOString(),
    level: LogLevel.FATAL,
    service: 'auth-service',
    message: 'Brute force attack detected from IP 45.22.19.112',
    metadata: { ip: '45.22.19.112', block_duration: '1h' }
  },
  {
    id: 'log-008',
    timestamp: new Date(Date.now() - 1000 * 60 * 1).toISOString(),
    level: LogLevel.INFO,
    service: 'frontend-api',
    message: 'Health check passed',
  }
];

export const NAVIGATION_ITEMS = [
  { name: 'Dashboard', path: '/' },
  { name: 'Log Explorer', path: '/logs' },
  { name: 'AI Analysis', path: '/analysis' },
  { name: 'Documentation', path: '/docs' },
];